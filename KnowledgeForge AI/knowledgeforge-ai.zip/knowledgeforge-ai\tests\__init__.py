"""KnowledgeForge AI test suite."""
